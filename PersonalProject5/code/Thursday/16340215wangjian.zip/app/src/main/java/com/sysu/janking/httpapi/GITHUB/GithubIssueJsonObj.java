package com.sysu.janking.httpapi.GITHUB;

public class GithubIssueJsonObj {
    public String title;
    public String body;
    public GithubIssueJsonObj(String title, String body){
        this.title = title;
        this.body = body;
    }
}
