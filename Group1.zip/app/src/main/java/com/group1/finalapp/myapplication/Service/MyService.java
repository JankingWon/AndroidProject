package com.group1.finalapp.myapplication.Service;

import com.group1.finalapp.myapplication.Model.LoginJsonObj;

import io.reactivex.Observable;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface MyService {
    @POST("/login")
    Observable<String> loginAuth(@Body LoginJsonObj user);

    @Headers("Content-Type: application/x-www-form-urlencoded")
    @POST("/cmd")
    Observable<String> sendCMD(@Body String  body);
}