package com.group1.finalapp.myapplication.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v4.widget.DrawerLayout;
import android.view.KeyEvent;
import android.widget.Toast;

import com.group1.finalapp.myapplication.Fragment.FirstFragment;
import com.group1.finalapp.myapplication.Fragment.SecondFragment;
import com.group1.finalapp.myapplication.R;

public class MainActivity extends AppCompatActivity
        implements NavigationDrawerFragment.NavigationDrawerCallbacks{

    /**
     * Fragment managing the behaviors, interactions and presentation of the navigation drawer.
     */
    private NavigationDrawerFragment mNavigationDrawerFragment;
    /**
     * Used to store the last screen title. For use in {@link #restoreActionBar()}.
     */
    private CharSequence mTitle;
    //每个fragment的实例
    private FirstFragment firstFragment = new FirstFragment();
    private SecondFragment secondFragment = new SecondFragment();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mNavigationDrawerFragment = (NavigationDrawerFragment)
                getFragmentManager().findFragmentById(R.id.navigation_drawer);

        mTitle = getTitle();
        Toast.makeText(MainActivity.this,mTitle,Toast.LENGTH_SHORT).show();
        // Set up the drawer.
        mNavigationDrawerFragment.setUp(
                R.id.navigation_drawer,
                (DrawerLayout) findViewById(R.id.drawer_layout));

    }
    //点击菜单之后更改视图
    @Override
    public void onNavigationDrawerItemSelected(int position) {
        // update the main content by replacing fragments
        FragmentManager fragmentManager = getFragmentManager();
        //获取session
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        Fragment fragment = null;
        switch (position){
            case 0:
                fragment = firstFragment;
                break;
            case 1:
                fragment = secondFragment;
                break;
            case 2:
                fragment = new SecondFragment();
                break;
        }
        //获取标题栏
        mTitle = getResources().getStringArray(R.array.drawer_menu)[position];
        //从activity传递数据
        fragment.setArguments(getIntent().getExtras());
        fragmentTransaction.replace(R.id.container,fragment);
        fragmentTransaction.commit();
        restoreActionBar();
    }
    //标题栏的恢复
    public void restoreActionBar() {
        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        //actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_STANDARD);
        actionBar.setDisplayShowTitleEnabled(true);
        actionBar.setTitle(mTitle);
    }

    //按下返回键收回导航栏
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            // 菜单键控制drawer
            if (mNavigationDrawerFragment.getmDrawerLayout().isDrawerOpen(mNavigationDrawerFragment.getmFragmentContainerView())){
                mNavigationDrawerFragment.getmDrawerLayout().closeDrawer(mNavigationDrawerFragment.getmFragmentContainerView());
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);

    }

}
