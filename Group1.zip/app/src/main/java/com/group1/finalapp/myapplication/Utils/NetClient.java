package com.group1.finalapp.myapplication.Utils;

import android.os.AsyncTask;

import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;

public class NetClient extends AsyncTask<Void,Void,String> {

    private Socket _sockClient;
    private String _strIp;
    private int    _nPort;
    private OutputStream _os;


    public int initSocket(String Ip,int nPort) throws IOException {
        _strIp=Ip;
        _nPort=nPort;
        return 1;
    }

    /**
     *
     * @param strSnd  the str to send
     * @return  the length of send str
     * @throws IOException
     */
    public int sendData(String strSnd) throws IOException,NullPointerException {
        _os=_sockClient.getOutputStream();
        _os.write(strSnd.getBytes());
        return strSnd.length();
    }

    @Override
    protected String doInBackground(Void... params) {
        try {
            _sockClient= new Socket(_strIp,_nPort);
            _sockClient.setSoTimeout(5000);
            sendData("hehe from android tcp client");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}