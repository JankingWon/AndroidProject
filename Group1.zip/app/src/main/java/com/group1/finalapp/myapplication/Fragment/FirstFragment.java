package com.group1.finalapp.myapplication.Fragment;

import android.app.Activity;
import android.app.Fragment;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.group1.finalapp.myapplication.Activity.MainActivity;
import com.group1.finalapp.myapplication.R;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.*;
import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.observers.DisposableObserver;
import io.reactivex.schedulers.Schedulers;

public class FirstFragment extends Fragment {
    //一些按钮
    private static Button LEDController1, LEDController2, LEDController3;
    private static Boolean LEDStatus = false;
    private static TextView textView;
    //服务器地址
    private static String baseURL = "http://111.230.11.142:8088/cmd";
    private static String session;
    //rxjava
    private CompositeDisposable mCompositeDisposable = new CompositeDisposable();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View currentView = inflater.inflate(R.layout.fragment_main, container, false);
        LEDController1 = currentView.findViewById(R.id.LED_controller1);
        LEDController2 = currentView.findViewById(R.id.LED_controller2);
        LEDController3 = currentView.findViewById(R.id.LED_controller3);
        textView = currentView.findViewById(R.id.tv);
        LEDController1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                controlLED("a");
            }
        });
        LEDController2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                controlLED("b");
            }
        });
        LEDController3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                controlLED("c");
            }
        });
        session = getArguments().getString("session");
        return currentView;
    }

    boolean controlLED(final String cmd){
        Observable<String> observable = Observable.create(new ObservableOnSubscribe<String>() {
            @Override
            public void subscribe(ObservableEmitter<String> observableEmitter) throws Exception {
                URL url = new URL(baseURL);
                HttpURLConnection conn = (HttpURLConnection)url.openConnection();
                conn.setConnectTimeout(5000);
                conn.setRequestMethod("POST");
                // 设置报文头
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                conn.setRequestProperty("Cookie",session);
                conn.getOutputStream().write(new String("cmd=" + cmd).getBytes());//设置输出流
                //InputStream转String
                /*if(conn.getResponseCode() == 200){
                    *//*BufferedInputStream bis = new BufferedInputStream((InputStream)conn.getContent());
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    int result = bis.read();
                    while(result != -1) {
                        byteArrayOutputStream.write((byte) result);
                        result = bis.read();
                    }
                    observableEmitter.onNext(byteArrayOutputStream.toString());*//*
                    observableEmitter.onNext( "控制成功");
                }else if(conn.getResponseCode() == 401){
                    observableEmitter.onNext("未授权");
                }else {
                    observableEmitter.onNext( "控制失败");
                }*/
                observableEmitter.onNext(String.valueOf(conn.getResponseCode()));
                observableEmitter.onComplete();
            }
        });
        DisposableObserver<String> disposableObserver = new DisposableObserver<String>() {
            @Override
            public void onNext(String  response) {
                textView.setText(response);
                if(response.equals("401")){
                    new AlertDialog.Builder(getActivity()).setTitle("错误").setMessage("请重新登录").setPositiveButton("确定",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    getActivity().finish();
                                }
                            }).create().show();
                    return;
                }else if(response.equals("200")){
                    if(cmd.equals("a")){
                        LEDController1.setBackgroundColor(getResources().getColor(R.color.white));
                    }else if (cmd.equals("b")){
                        LEDController2.setBackgroundColor(getResources().getColor(R.color.turquoise));
                    }else{
                        LEDController3.setBackgroundColor(getResources().getColor(R.color.pink));
                    }
                }else{
                    Toast.makeText(getActivity(),"服务器错误", Toast.LENGTH_SHORT).show();
                }
                Log.d("LED", "onNext: "+ response );
            }
            @Override
            public void onComplete() {
                //Toast.makeText(, "提交完成", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onError(Throwable e) {
                //Toast.makeText(getActivity(), "提交失败", Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }

        };
        //在新线程监听
        observable.subscribeOn(Schedulers.newThread())
                //在主线程更新
                .observeOn(AndroidSchedulers.mainThread())
                //绑定
                .subscribe(disposableObserver);
        //管理DisposableObserver的容器
        mCompositeDisposable.add(disposableObserver);
        return true;
    }


}