package com.group1.finalapp.myapplication.Model;

public class LoginJsonObj {
    public String username;
    public String password;
    public LoginJsonObj(String username, String password){
        this.username = username;
        this.password = password;
    }
}
